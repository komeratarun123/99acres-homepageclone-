import { NextDirective } from './next.directive';

describe('NextDirective', () => {
  it('should create an instance', () => {
    const directive = new NextDirective();
    expect(directive).toBeTruthy();
  });
});
