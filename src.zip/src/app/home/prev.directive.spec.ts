import { PrevDirective } from './prev.directive';

describe('PrevDirective', () => {
  it('should create an instance', () => {
    const directive = new PrevDirective();
    expect(directive).toBeTruthy();
  });
});
